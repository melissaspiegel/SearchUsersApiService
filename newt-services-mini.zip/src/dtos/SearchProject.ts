export type SearchProject = {
  id: string;
  title: string;
  technologies?: unknown;
};
